




<?php $__env->startSection('content'); ?>

<div class="container">

<div class="center">
    <table class="highlight">
        <thead>
            <tr>
                <th>Process Name</th>
                <th>Priority</th>
                <th>Time Alloted</th>
            </tr>
        </thead>	
        <tbody>
            <?php
            while($rows = mysqli_fetch_assoc($result)){
            ?>	
                <tr>
                    <td><?php echo $rows['processname'] ?></td>
                    <td><?php echo $rows['priority'] ?></td>
                    <td><?php echo $rows['quantam'] ?></td>
                </tr>
            <?php
            }
            mysqli_free_result($result);
            ?>
        </tbody>
    </table>
</div>
<form action="insertProcess.php" method="POST">
<div class="form-field center-align">
                    <button class="btn-large red darken-1 z-depth-5">
                        <a href="insertProcess.php" style="text-decoration:none;color:white;">
                        ADD PROCESS
                        </a>
                    </button>
                </div><br>
            <div class="form-field center-align">
                    <button class="btn-large red darken-1 z-depth-5">
                        <a href="finalwindow.php" style="text-decoration:none;color:white;">
                        START
                        </a>
                    </button>
                </div><br>
            </br>
             <div class="form-field center-align">
            <button class="btn-small red darken-1 z-depth-2">
                            <a href="signout.php" style="text-decoration: none; color: white">    
                        Sign Out
                            </a>
                    </button>    
            </div></br>

</div>
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Homepage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project_laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>