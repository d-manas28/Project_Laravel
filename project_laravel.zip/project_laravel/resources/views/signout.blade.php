//signout.php

$request->session()->forget('key');